window.onload = function () {

  const myCarousel = new Carousel(document.querySelector(".carousel"), {});

  // const myCarouse2 = new Carousel(document.querySelector(".carousel2"), {
  //     // Options
  //     initialPage:6
  // });
}


