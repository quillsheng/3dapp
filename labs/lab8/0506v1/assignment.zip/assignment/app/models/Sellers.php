<?php
/**
 * Sellers
 */

namespace app\models;

class Sellers extends Model
{
    public $table = "sellers";

}

?>
