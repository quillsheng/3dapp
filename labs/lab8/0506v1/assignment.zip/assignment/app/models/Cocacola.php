<?php
/**
 * Cocacola
 */

namespace app\models;

class Cocacola extends Model
{
    public $table = "cocacola";
}

?>
