<?php
/**
 * Sellers
 */

namespace app\models;

class Beyond extends Model
{
    public $table = "beyond";

}

?>
