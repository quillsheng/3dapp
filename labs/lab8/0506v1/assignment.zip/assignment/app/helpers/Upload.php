<?php
/**
* Upload
*/

namespace app\helpers;

class Upload
{
	function __construct()
	{
		$this->f3= \Base::instance();
		$this->web=\Web::instance();
	}


}
?>
