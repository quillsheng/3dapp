
<?php echo $this->render($header,NULL,get_defined_vars(),0); ?>
<div class="container">
  <h1>
    Insert About Contents
  </h1>
</div>

<?php echo $this->render($footer,NULL,get_defined_vars(),0); ?>
