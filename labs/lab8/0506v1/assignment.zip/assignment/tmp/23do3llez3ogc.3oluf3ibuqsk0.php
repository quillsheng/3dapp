
<?php echo $this->render($header,NULL,get_defined_vars(),0); ?>
<div>
  <h1>
    contact
  </h1>
</div>

<?php echo $this->render($footer,NULL,get_defined_vars(),0); ?>
